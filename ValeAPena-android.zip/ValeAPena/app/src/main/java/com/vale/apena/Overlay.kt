package com.vale.apena

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class Overlay(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: LinearLayout? = null
    val showing get() = view != null

    private fun money(x: Double) = "R$ " + String.format("%.2f", x).replace(".", ",")

    fun show(r: Result, slope: Int, onSlope: (Int) -> Unit) {
        if (!Settings.canDrawOverlays(ctx)) return
        hide()
        val cores = intArrayOf(0xFF16A34A.toInt(), 0xFFD97706.toInt(), 0xFFDC2626.toInt())
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ctx.dp(14), ctx.dp(10), ctx.dp(14), ctx.dp(10))
            background = GradientDrawable().apply { setColor(cores[r.level]); cornerRadius = ctx.dp(16).toFloat() }
        }
        root.addView(TextView(ctx).apply {
            text = r.title; textSize = 22f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
        })
        var det = "${money(r.porHora)}/h • ${money(r.porKm)}/km • ${r.minutos} min • líquido ${money(r.liquido)}"
        if (r.level != 0) det += "\nMínimo para valer: ${money(r.valorMinimo)}"
        root.addView(TextView(ctx).apply { text = det; textSize = 13f; setTextColor(Color.WHITE) })
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, ctx.dp(8), 0, 0) }
        arrayOf("Plano", "Leve", "Média", "Forte").forEachIndexed { i, n ->
            row.addView(TextView(ctx).apply {
                text = n; textSize = 13f; gravity = Gravity.CENTER
                setPadding(ctx.dp(10), ctx.dp(6), ctx.dp(10), ctx.dp(6))
                setTextColor(if (i == slope) cores[r.level] else Color.WHITE)
                background = GradientDrawable().apply {
                    setColor(if (i == slope) Color.WHITE else 0x33FFFFFF); cornerRadius = ctx.dp(10).toFloat()
                }
                setOnClickListener { onSlope(i) }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = ctx.dp(4) })
        }
        root.addView(row)
        val lp = WindowManager.LayoutParams(
            ctx.resources.displayMetrics.widthPixels - ctx.dp(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = ctx.dp(40) }
        try { wm.addView(root, lp); view = root } catch (e: Exception) { view = null }
    }

    fun hide() {
        view?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        view = null
    }
}
