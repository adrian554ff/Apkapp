package com.vale.apena

import android.content.Context

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("vap", Context.MODE_PRIVATE)
    var metaHora: Float get() = sp.getFloat("mh", 20f); set(v) = sp.edit().putFloat("mh", v).apply()
    var metaKm: Float get() = sp.getFloat("mk", 2.5f); set(v) = sp.edit().putFloat("mk", v).apply()
    var velocidade: Float get() = sp.getFloat("vel", 15f); set(v) = sp.edit().putFloat("vel", v).apply()
    var desgaste: Float get() = sp.getFloat("cus", 0.2f); set(v) = sp.edit().putFloat("cus", v).apply()
    var espera: Float get() = sp.getFloat("esp", 5f); set(v) = sp.edit().putFloat("esp", v).apply()
    var ladeira: Int get() = sp.getInt("lad", 0); set(v) = sp.edit().putInt("lad", v).apply()
    var debug: Boolean get() = sp.getBoolean("dbg", false); set(v) = sp.edit().putBoolean("dbg", v).apply()
    var last: String get() = sp.getString("last", "") ?: ""; set(v) = sp.edit().putString("last", v).apply()
}
