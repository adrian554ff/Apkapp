package com.vale.apena

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private lateinit var p: Prefs
    private lateinit var status: TextView
    private lateinit var capture: TextView
    private lateinit var spin: Spinner
    private lateinit var dbg: Switch
    private val fields = LinkedHashMap<String, EditText>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = Prefs(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(28), dp(16), dp(28)) }
        setContentView(ScrollView(this).apply { addView(root) })
        root.addView(TextView(this).apply { text = "🚲 Vale a Pena"; textSize = 26f })
        status = TextView(this).apply { setPadding(0, dp(8), 0, dp(8)) }
        root.addView(status)
        root.addView(btn("1) Ativar leitura de tela") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(btn("2) Permitir sobrepor a outros apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        field(root, "Meta R$/hora (líquido)", "mh", p.metaHora)
        field(root, "Meta R$/km (líquido)", "mk", p.metaKm)
        field(root, "Velocidade no plano (km/h)", "vel", p.velocidade)
        field(root, "Desgaste da bike (R$/km)", "cus", p.desgaste)
        field(root, "Espera média no restaurante (min)", "esp", p.espera)
        root.addView(TextView(this).apply { text = "Ladeira padrão da sua região"; setPadding(0, dp(12), 0, 0) })
        spin = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Plano", "Ladeira leve", "Ladeira moderada", "Ladeira forte"))
            setSelection(p.ladeira)
        }
        root.addView(spin)
        dbg = Switch(this).apply { text = "Modo captura (guarda o texto lido da tela)"; isChecked = p.debug }
        root.addView(dbg)
        root.addView(btn("Salvar") { save() })
        root.addView(TextView(this).apply { text = "Última captura (copie e me envie para ajustar a leitura):"; setPadding(0, dp(16), 0, 0) })
        capture = TextView(this).apply { setTextIsSelectable(true); textSize = 12f }
        root.addView(capture)
    }

    override fun onResume() {
        super.onResume()
        val acc = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)
        val ov = Settings.canDrawOverlays(this)
        status.text = (if (acc) "✅" else "❌") + " Leitura de tela\n" + (if (ov) "✅" else "❌") + " Sobreposição"
        capture.text = p.last.ifEmpty { "(vazia)" }
    }

    private fun save() {
        fun v(k: String, d: Float) = fields[k]!!.text.toString().replace(",", ".").toFloatOrNull() ?: d
        p.metaHora = v("mh", 20f); p.metaKm = v("mk", 2.5f); p.velocidade = v("vel", 15f)
        p.desgaste = v("cus", 0.2f); p.espera = v("esp", 5f)
        p.ladeira = spin.selectedItemPosition; p.debug = dbg.isChecked
        Toast.makeText(this, "Salvo", Toast.LENGTH_SHORT).show()
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

    private fun field(root: LinearLayout, label: String, key: String, value: Float) {
        root.addView(TextView(this).apply { text = label; setPadding(0, dp(12), 0, 0) })
        val e = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(value.toString())
        }
        fields[key] = e; root.addView(e)
    }
}
