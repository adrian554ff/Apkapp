package com.vale.apena

data class Offer(val valor: Double, val kmColeta: Double, val kmEntrega: Double)

object OfferParser {
    private val money = Regex("""R\$\s*(\d{1,3}(?:\.\d{3})*,\d{2}|\d+,\d{2}|\d+)""")
    private val dist = Regex("""(\d+(?:[.,]\d+)?)\s*(km|m)\b""", RegexOption.IGNORE_CASE)

    /** Leitura genérica: 1º R$ = valor; 1ª distância = coleta, 2ª = entrega.
     *  Com só uma distância, ela é tratada como entrega. Ajustar por app depois dos prints. */
    fun parse(text: String): Offer? {
        val v = money.find(text)?.groupValues?.get(1)
            ?.replace(".", "")?.replace(",", ".")?.toDoubleOrNull() ?: return null
        val d = dist.findAll(text).mapNotNull {
            val n = it.groupValues[1].replace(",", ".").toDoubleOrNull() ?: return@mapNotNull null
            if (it.groupValues[2].lowercase() == "m") n / 1000 else n
        }.toList()
        if (d.isEmpty()) return null
        return if (d.size >= 2) Offer(v, d[0], d[1]) else Offer(v, 0.0, d[0])
    }
}
