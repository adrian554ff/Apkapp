package com.vale.apena

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class OfferReaderService : AccessibilityService() {
    private lateinit var prefs: Prefs
    private lateinit var overlay: Overlay
    private var lastSig = ""
    private var slope = 0
    // Trechos do nome do pacote dos apps de entrega. Confirme com o "Modo captura" (mostra o pacote).
    private val keys = listOf("ifood", "didi", "99", "uber", "keeta", "meituan")

    override fun onServiceConnected() {
        prefs = Prefs(this); overlay = Overlay(this); slope = prefs.ladeira
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString()?.lowercase() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        if (keys.none { pkg.contains(it) }) { overlay.hide(); lastSig = ""; return }
        val root = rootInActiveWindow ?: return
        val sb = StringBuilder(); collect(root, sb, 0)
        val text = sb.toString()
        if (prefs.debug && (text.contains("R$") || text.contains("km"))) {
            prefs.last = "pacote: $pkg\n$text".take(4000)
        }
        val offer = OfferParser.parse(text)
        if (offer == null) { overlay.hide(); lastSig = ""; return }
        val sig = "$pkg|${offer.valor}|${offer.kmColeta}|${offer.kmEntrega}"
        if (sig == lastSig && overlay.showing) return
        lastSig = sig
        slope = prefs.ladeira
        render(offer)
    }

    private fun render(o: Offer) {
        overlay.show(Evaluator.eval(o, prefs, slope), slope) { s -> slope = s; render(o) }
    }

    private fun collect(n: AccessibilityNodeInfo?, sb: StringBuilder, d: Int) {
        if (n == null || d > 40) return
        n.text?.let { sb.append(it).append(" | ") }
        n.contentDescription?.let { sb.append(it).append(" | ") }
        for (i in 0 until n.childCount) collect(n.getChild(i), sb, d + 1)
    }

    override fun onInterrupt() { overlay.hide() }
    override fun onDestroy() { overlay.hide(); super.onDestroy() }
}
