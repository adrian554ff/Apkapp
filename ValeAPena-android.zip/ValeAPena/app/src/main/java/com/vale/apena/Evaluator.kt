package com.vale.apena

data class Result(
    val level: Int, // 0 vale, 1 dúvida, 2 não vale
    val title: String,
    val liquido: Double,
    val porHora: Double,
    val porKm: Double,
    val minutos: Int,
    val valorMinimo: Double
)

object Evaluator {
    val SLOPE = doubleArrayOf(1.0, 0.8, 0.6, 0.45)

    fun eval(o: Offer, p: Prefs, slope: Int): Result {
        val km = o.kmColeta + o.kmEntrega
        val vel = p.velocidade * SLOPE[slope]
        val min = km / vel * 60 + p.espera + 2
        val h = min / 60
        val liq = o.valor - km * p.desgaste
        val ph = liq / h
        val pk = if (km > 0) liq / km else 0.0
        val okH = ph >= p.metaHora
        val okK = pk >= p.metaKm
        val nearH = ph >= p.metaHora * 0.8
        val nearK = pk >= p.metaKm * 0.8
        val level = when {
            okH && okK -> 0
            nearH && nearK -> 1
            else -> 2
        }
        val title = arrayOf("✅ VALE A PENA", "🤔 NA DÚVIDA", "❌ NÃO VALE")[level]
        val minimo = maxOf(p.metaHora * h, p.metaKm * km) + km * p.desgaste
        return Result(level, title, liq, ph, pk, Math.round(min).toInt(), minimo)
    }
}
